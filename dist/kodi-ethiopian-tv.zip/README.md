# kodi-ethiopian-tv
Watch live streams from various Ethiopian broadcast television sources, currently supporting EBS TV, EBC 1, EBC 2, and EBC 3 channels.

I totally lost the source for this project, but I'll update this repo as soon as I get my hands on it....
